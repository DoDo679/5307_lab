/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myfirstcup.web;

import myfirstcup.ejb.DukesBirthdayBean;
import java.io.Serializable;
import java.util.Date;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

/**
 *
 * @author Anson679
 */
public class MyDukesBDayBean implements Serializable {      
    protected int age;
    protected Date yourBD;
    protected int ageDiff;
    protected int absAgeDiff;
    protected Double averageAgeDifference;
    protected String comparisonText;
    
    public MyDukesBDayBean() {
    }
    
    protected void processBirthday(DukesBirthdayBean dukesBDejBean) {
        setAgeDiff(dukesBDejBean.getAgeDifference(yourBD));
        setAbsAgeDiff(Math.abs(ageDiff));
        setAverageAgeDifference(dukesBDejBean.getAverageAgeDifference());
        if (ageDiff == 0) {
            setComparisonText("the same age as");
        } else {
            setComparisonText(absAgeDiff + " year"
                    + (absAgeDiff == 1 ? " " : "s ")
                    + (ageDiff < 0 ? "younger than" : "older than"));
        }
    }   
    
    public int getAge() {
        try {
            Client client = ClientBuilder.newClient();
            WebTarget target
                    = client.target("http://localhost:8080/mydukes-age/webresources/dukesAge");
            String response = target.request().get(String.class);
            age = Integer.parseInt(response);

        } catch (IllegalArgumentException | NullPointerException
                | WebApplicationException ex) {
            // Do nothing for the time being for simplicity
        }
        return age;
    }
    
    public void setYourBD(Date yourBD, DukesBirthdayBean dukesBDejb) {
        this.yourBD = yourBD;
        processBirthday(dukesBDejb);
    }

    private void setAgeDiff(int ageDifference) {
        ageDiff = ageDifference;        
    }

    private void setAbsAgeDiff(int abs) {
        absAgeDiff = abs;
    }

    private void setAverageAgeDifference(Double averageAgeDifference0) {
        averageAgeDifference = averageAgeDifference0;
    }

    private void setComparisonText(String the_same_age_as) {
        comparisonText = the_same_age_as;
    }
}
