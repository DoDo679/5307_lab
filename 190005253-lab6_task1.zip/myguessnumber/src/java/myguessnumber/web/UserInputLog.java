/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myguessnumber.web;

import java.io.Serializable;

/**
 *
 * @author Anson679
 */
public class UserInputLog implements Serializable{
    private final Integer userNumber;
    private final String largeOfSmaller;

    public Integer getUserNumber() {
        return userNumber;
    }

    public String getLargeOfSmaller() {
        return largeOfSmaller;
    }

    public UserInputLog(Integer userNumber, String largeOfSmaller) {
        this.userNumber = userNumber;
        this.largeOfSmaller = largeOfSmaller;
    }
    
    @Override
    public String toString(){
        return "You guessed " + userNumber + ", but my number is " + 
                largeOfSmaller + ".";
    }
}
