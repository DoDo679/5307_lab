package myguessnumber.web;

import java.io.Serializable;
import java.util.Random;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

@Named
@SessionScoped
public class UserNumberBean implements Serializable {

    Integer randomInt = null;
    private Integer userNumber = null;
    String response = null;
    private int maximum = 100;
    private int minimum = 0;
    private int userguessmaximum = 100;
    private int userguessminimum = 0;
    
    //User Input Log
    ArrayList<UserInputLog> inputLog = new ArrayList<UserInputLog>();
    String largeOfSmaller;

    public ArrayList<UserInputLog> getInputLog() {        
        return inputLog;
    }

    public UserNumberBean() {
        Random randomGR = new Random();
        randomInt = new Integer(randomGR.nextInt(maximum));
        // Print number to server log
        System.out.println("Duke's number: " + randomInt);
    }

    public void setUserNumber(Integer user_number) {
        userNumber = user_number;
    }

    public Integer getUserNumber() {
        return userNumber;
    }

    public String getResponse() {
        if ((userNumber == null) || (userNumber.compareTo(randomInt) != 0)) {
            
            //ToolTip
            if(userNumber > randomInt){
                userguessmaximum = userNumber;
                largeOfSmaller = "Too large";
            }else{
                userguessminimum = userNumber;
                largeOfSmaller = "Too small";
            }
            
            //User Input Log
            // String nowLog = "You guessed " + userNumber + ", but the number is " + largeOfSmaller;
            inputLog.add( new UserInputLog(userNumber, largeOfSmaller) );
            
            return "Sorry, " + userNumber + " is incorrect.";
        } else {
            
            //invalidate user session
            FacesContext context = FacesContext.getCurrentInstance();
            HttpSession session = (HttpSession) context.getExternalContext().getSession(false);
            session.invalidate();
            
            return "Yay! You got it!";
        }
    }

    public int getMaximum() {
        return (this.maximum);
    }

    public void setMaximum(int maximum) {
        this.maximum = maximum;
    }

    public int getMinimum() {
        return (this.minimum);
    }

    public void setMinimum(int minimum) {
        this.minimum = minimum;
    }
    
    public int getUserguessmaximum() {
        return userguessmaximum;
    }

    public void setUserguessmaximum(int userguessmaximum) {
        this.userguessmaximum = userguessmaximum;
    }

    public int getUserguessminimum() {
        return userguessminimum;
    }

    public void setUserguessminimum(int userguessminimum) {
        this.userguessminimum = userguessminimum;
    }
}
