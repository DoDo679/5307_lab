/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simpleForum.web;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
// provided import(s) not shown
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
// provided import(s) not shown
import javax.servlet.http.HttpSession;
// provided import(s) not shown

/**
 *
 * @author Anson679
 */
@WebServlet("/")
public class SimpleForumServlet extends HttpServlet {
    private static final ArrayList<String> USERNAMES = new ArrayList<String>();
    private static final ArrayList<Integer> MESSAGE_UID = new ArrayList<Integer>();
    private static final ArrayList<String> MESSAGES = new ArrayList<String>();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getQueryString() == null) {
            doPost(request, response);
        } else {
            throw new ServletException("Illegal request");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) {
            action = "";
        }
        String url = "/register.jsp";
        if (isUserValid(request)) {
            if (action.equals("post")) {
                String message = request.getParameter("message");  // get form data
                if (message != null) {  // message has something in it
                    synchronized (this.getClass()) {
                        // Get uid from session and add to messageUID
                        HttpSession session = request.getSession();
                        Integer id = (Integer)session.getAttribute("uid");                        
                        MESSAGE_UID.add(id);
                        // Add message to list of messages
                        MESSAGES.add(message);
                    }
                }
                request.setAttribute("usernames", USERNAMES);
                request.setAttribute("messageUID", MESSAGE_UID);
                request.setAttribute("messages", MESSAGES);
                url = "/show.jsp";
            } else {
                url = "/post.jsp";
            }
        } else if (action.equals("register")) {
            String username = request.getParameter("username");  // get form data
            if (username == null) {
                throw new ServletException("Null username");
            }
            if (registerUserDone(username, request.getSession())) {
                url = "/post.jsp";
            } else {
                request.setAttribute("hint", "Someone else has used " + username
                        + " as user name already.  Please try another one.");
            }
        }

        // Forward request object and response object to JSP with url
        getServletContext().getRequestDispatcher(url).forward(request, response);  
        }
    

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private boolean isUserValid(HttpServletRequest request) {
        // Return true if both uid and username are stored in session
        Integer userID_Valid     = (Integer) request.getSession().getAttribute("uid");
        String userName_Valid   = (String) request.getSession().getAttribute("username");
        if( userID_Valid != null && userName_Valid != null){
            return true;
        }else {
            return false;
        }            
    }

    private boolean registerUserDone(String username, HttpSession session)
            throws ServletException {
        if (!USERNAMES.contains(username)) {  // user not yet registered
            synchronized (this.getClass()) {
                synchronized (session.getId().intern()) {
                    // Add username to list of usernames
                    // Store uid and username in session
                    USERNAMES.add(username);
                    session.setAttribute("uid", (USERNAMES.size() - 1));
                    session.setAttribute("username", username);
                    //Testing
                    String user_name = (String) session.getAttribute("username");
                    Integer user_id = (Integer) session.getAttribute("uid");
                    System.out.println("New user    : " + user_name);
                    System.out.println("New userID  : " + user_id);
                }
            }
            return true;
        }
        return false;  // user registered before
    }
}
